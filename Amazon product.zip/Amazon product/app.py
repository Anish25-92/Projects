from flask import Flask,render_template,request,jsonify
from flask_cors import CORS,cross_origin
import requests
import os
import time
from bs4 import BeautifulSoup as bs
from urllib.request import urlopen as uReq
from selenium.common.exceptions import StaleElementReferenceException, NoSuchElementException
from selenium import webdriver
import pandas as pd

app = Flask(__name__)

@app.route('/',methods=['GET'])  # route to display the home page
@cross_origin()
def homePage():
    return render_template("index.html")

@app.route('/review',methods=['POST','GET']) # route to show the review comments in a web UI
@cross_origin()
def index():
    if request.method == 'POST':
        try:
            driver = webdriver.Chrome(r'C:\Users\USER\Desktop\Ineuron-FSDS\Notes\Projects\Amazon product\chromedriver.exe')
            searchString = request.form['content'].replace(" ","")
            Amazon_url = "https://www.amazon.in/s?k=" + searchString
            driver.get(Amazon_url)
            start_page = int(input())
            end_page = int(input())
            urls = []
            for page in range(start_page, end_page - 1):
                try:
                    page_urls = driver.find_elements_by_xpath('//a[@class="a-link-normal s-no-outline"]')

                    for url in page_urls:
                        url = url.get_attribute('href')
                        if url[0:4] == 'http':
                          urls.append(url)


                # Moving to next page
                    nxt_button = driver.find_element_by_xpath('//span[@class="s-pagination-strip"]/a')
                    if nxt_button.text == 'Next→':
                        nxt_button.click()
                        time.sleep(5)
                    elif driver.find_element_by_xpath('//span[@class="s-pagination-strip"]/span').text == 'Next→':
                            print("No new pages exist. Breaking the loop")
                            break

                except StaleElementReferenceException as e:
                    print("Stale Exception")
                    next_page = nxt_button.get_attribute('href')
                    driver.get(next_page)
            prod_dict = {}
            prod_dict['Name']=[]
            prod_dict['Rating']=[]
            prod_dict['Price']=[]
            prod_dict['Availability']=[]
            prod_dict['Other Details']=[]
            prod_dict['URL']=[]
            reviews = []

            for url in urls:
                 driver.get(url)  # Loading the webpage by url


                 try:
                     name = driver.find_element_by_xpath('//h1[@id="title"]/span')  # Extracting Name from xpath
                     prod_dict['Name'].append(name.text)
                 except NoSuchElementException:
                     prod_dict['Name'].append('-')
                 try:
                      rating = driver.find_element_by_xpath('//span[@id="acrPopover"]')  # Extracting Ratings from xpath
                      prod_dict['Rating'].append(rating.get_attribute("title"))
                 except NoSuchElementException:
                       prod_dict['Rating'].append('-')
                 try:
                       avl = driver.find_element_by_xpath('//div[@id="availability"]/span')  # Extracting Availability from xpath
                       prod_dict['Availability'].append(avl.text)
                 except NoSuchElementException:
                        prod_dict['Availability'].append('-')

                 try:
                       price = driver.find_element_by_xpath('//span[@class="a-price-whole"]')  # Extracting Price from xpath
                       prod_dict['Price'].append(price.text)
                 except NoSuchElementException:
                       prod_dict['Price'].append('-')
                 try:  # Extracting Other Details from xpath
                       dtls = driver.find_element_by_xpath('//ul[@class="a-unordered-list a-vertical a-spacing-mini"]')
                       prod_dict['Other Details'].append('  ||  '.join(dtls.text.split('\n')))
                 except NoSuchElementException:
                       prod_dict['Other Details'].append('-')
                       prod_dict['URL'].append(url)
                 reviews.append(prod_dict)
            return render_template('results.html', reviews=reviews[0:(len(reviews) - 1)])
        except Exception as e:
            return 'something is wrong'
    else:
        return render_template('index.html')
if __name__ == "__main__":
    #app.run(host='127.0.0.1', port=8001, debug=True)
	app.run(debug=True)
